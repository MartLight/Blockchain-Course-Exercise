// shared/rpc.ts
// One place that decides which RPC endpoint to use for a chain.
// Used by truffle-config.js (deploying) and notifier/ (the email watcher), so the two can never talk to different endpoints.
//
// The order is:
//   1. RPC_URL_<KEY>           an override you set for one network
//   2. ETHEREUM_PROVIDER_URL   mainnet only
//   3. Infura                  when INFURA_PROJECT_ID is set
//   4. the public RPC listed in shared/chains.json

export interface ChainForRpc {
  key: string;
  infura?: string | null;
  rpcUrls: string[];
}

export function rpcUrl(chain: ChainForRpc, env: Record<string, string | undefined> = process.env): string {
  const override = env['RPC_URL_' + chain.key.toUpperCase()];

  if (override) return override;

  if (chain.key === 'mainnet' && env.ETHEREUM_PROVIDER_URL) return env.ETHEREUM_PROVIDER_URL;

  if (env.INFURA_PROJECT_ID && chain.infura) return `https://${chain.infura}.infura.io/v3/${env.INFURA_PROJECT_ID}`;

  return chain.rpcUrls[0];
}
