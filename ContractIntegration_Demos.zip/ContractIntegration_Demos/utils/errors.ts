// Turns the raw error from a wallet or a contract into a sentence a user can act on.
// The raw message is for developers; this is for the person looking at the screen.
export function friendlyError(err: any): string {
  const raw = [err?.message, err?.cause?.message, err?.data?.message, err?.error?.message]
    .filter(Boolean)
    .join(" | ");

  if (err?.code === 4001 || /user (denied|rejected)|rejected the request|ACTION_REJECTED/i.test(raw)) {
    return "You rejected the transaction in your wallet. Nothing was written to the chain.";
  }
  if (/EnforcedPause|paused/i.test(raw)) return "Registrations are paused by the administrator right now.";
  if (/OwnableUnauthorizedAccount/i.test(raw)) {
    return "Only the administrator (the account that deployed the contracts) can do this. Pick that account.";
  }
  if (/Offender is not a registered/i.test(raw)) return "The offender is not a registered vehicle. Register it first.";
  if (/Reporter is not a registered/i.test(raw)) return "The reporter is not a registered vehicle. Register it first.";
  if (/cannot report itself/i.test(raw)) return "A vehicle cannot report itself. Use two different pseudonyms.";
  if (/Offender is already revoked|Offender already revoked/i.test(raw)) return "That vehicle is already revoked.";
  if (/Reason cannot be empty/i.test(raw)) return "A reason is required.";
  if (/Report does not exist/i.test(raw)) return "There is no report with that number.";
  if (/Report already processed/i.test(raw)) return "That report has already been processed.";
  if (/Vehicle not registered/i.test(raw)) return "That vehicle is not registered. Register it first.";
  if (/Vehicle is revoked/i.test(raw)) return "That vehicle is revoked, so it cannot receive a license.";
  if (/License ID already used/i.test(raw)) return "That license number is already used. Choose another.";
  if (/Cannot reach Ganache/i.test(raw)) return String(err.message);
  if (/already registered/i.test(raw)) return "That pseudonym is already registered. Choose another one.";
  if (/revoked and cannot register/i.test(raw)) return "This wallet's identity is revoked, so it cannot register a new one.";
  if (/cannot be empty/i.test(raw)) return "A pseudonym cannot be empty.";
  if (/insufficient funds/i.test(raw)) return "This wallet does not have enough ETH to pay for the transaction.";
  if (/No wallet found/i.test(raw)) return String(err.message);
  if (/not deployed on chain/i.test(raw)) return String(err.message);
  return raw.slice(0, 220) || "Something went wrong.";
}
