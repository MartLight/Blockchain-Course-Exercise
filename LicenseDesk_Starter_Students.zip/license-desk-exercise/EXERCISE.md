# Exercise: the License Desk

**Time:** about 2 hours, plus about 20 minutes to deploy your contracts with Remix. **Work:** alone, on your own Git branch. **Hand in:** your branch, one screenshot and a short reflection (section 8).

The app you already know (the three contract-integration demos) has a new page, **License desk** (`/desk`). Its screen
is finished, but the four functions that talk to the blockchain are missing. You will write them: two **reads**, one
**write** and one **event search**. When you finish, a licensing officer can look up any license, see whether it is
valid and why, revoke it, and see the latest licenses issued, with every number coming straight from the chain.

## 1. The requirement

> **User story.** As a licensing officer, I want to look up a license and see whether it is valid and why, revoke it
> if needed, and see the latest licenses issued, so that I can answer a driver's question without reading raw blockchain data.

**Acceptance criteria**

| # | Criterion |
|---|---|
| AC1 | Looking up an existing license shows one of four status badges (Valid, Expired, Revoked, Vehicle revoked) and its details. |
| AC2 | A number that was never issued shows "No license with that number was ever issued." |
| AC3 | "Find its license" works from a vehicle's pseudonym; a vehicle without a license shows a clear message. |
| AC4 | The administrator can revoke a valid license: progress steps, a receipt, and the badge changes to Revoked. Other accounts cannot. |
| AC5 | "Latest licenses issued" lists the newest first, at most 10, read from the contract's events. |
| AC6 | Looking things up is **free**: no transaction, no gas. (You will prove this in section 5.) |
| AC7 | `npm test` passes (11 tests). |

## 2. Three ways to talk to a contract

You have met all three. This exercise uses each once.

| | Call (read) | Send (write) | Events |
|---|---|---|---|
| Code | `contract.methods.getLicense(id).call()` | `contract.methods.revokeLicense(id).send({ from })` | `contract.getPastEvents("LicenseIssued", {...})` |
| Changes the chain? | No | Yes | No (reads the log) |
| Costs gas / needs a signature? | No / No | Yes / Yes | No / No |
| Returns | the value(s) | a receipt (hash, block, gas, events) | a list of past events |

Three details trip people up:

- **Numbers come back as `bigint`**, and times are in **seconds**, while JavaScript `Date` wants **milliseconds**. `new Date(Number(raw.expiryTime) * 1000)`.
- **A function with several return values** (like `getLicense`) comes back as an object; read the values **by name**: `raw.issued`, `raw.isActive`.
- **A contract cannot return "nothing".** `getLicenseByVehicle` returns an empty string `""` when there is no license. Your code must turn that into something clearer.

## 3. Set up

First, for both routes:

```bash
npm install                       # once (about 2 minutes)
git checkout -b feature/license-desk
npm test                          # 11 tests fail: that is your starting point (no blockchain needed)
```

Then choose **one route** for the blockchain. Your instructor will say which. You do not change any Solidity in either.

**Route A: your own contracts on Sepolia, deployed from Remix (the default).** Follow **`REMIX.md`**: deploy the three contracts from your browser
with MetaMask, copy the three addresses and one block number into `.env.local`, and make the four sample licenses by hand. Then:

```bash
npm run dev                       # the app, http://localhost:3000 (restart it after editing .env.local)
```

**Route B: a local blockchain on your computer (Ganache).** No wallet and no test ETH. In three terminals:

```bash
npm run chain                     # terminal 1: the local blockchain. Leave it running and watch its output.
npm run deploy:local              # terminal 2: put the three contracts on it
npm run seed                      # terminal 2: create four sample licenses (it prints their numbers)
npm run dev                       # terminal 3: the app. In the page, click "Local Ganache" at the top.
```

Open http://localhost:3000/desk. Press **Look up** with any text: you get a red message that starts with `TODO Task 1`.
That is the page telling you which function is still missing. (If `Contracts not found` shows in the bar: on Route A check the addresses in
`.env.local` and restart; on Route B run `npm run deploy:local` again, because stopping the chain erases it.)

**Do not edit** anything except `utils/desk.ts`. Commit after each task: `task 1: fetchLicense`.

## 4. The tasks (all in `utils/desk.ts`)

Each function has its specification in the comment above it. Read it, then write the function.

### Task 1 (read): `fetchLicense`

Look up one license and work out its status.

1. Call `getLicense(licenseId)`. If `issued` is false, return `null`.
2. Call `isLicenseValid(licenseId)`.
3. Build the `LicenseInfo` object. Work out `status` in the order: `valid`, then `revoked`, then `expired`, then `vehicle-revoked`.

**Predict before you run:** `isLicenseValid` is only a yes/no. Why can the page not just show "Valid" or "Invalid"? (The officer
needs to know *why*. That is why the other fields are read too.)

<details><summary>Hint: reading the answer</summary>

`const raw: any = await contracts.license.methods.getLicense(licenseId).call();` then use `raw.issued`, `raw.isActive`,
`raw.expiryTime`, `raw.vehiclePseudonym`, `raw.owner`, `raw.licenseType`, `raw.issueTime`.
</details>
<details><summary>Hint: "expired" needs a comparison</summary>

`expiresAt.getTime() < now`: `now` is in milliseconds, like `getTime()`. The `now` parameter is there so a test can fix the clock.
</details>

**Check:** the six `task 1` tests pass. In the browser look up each of your four sample license numbers (the table at the end of `REMIX.md`, or the ones `npm run seed` printed): you should see Valid,
Expired, Revoked and Vehicle revoked. **Commit.**

### Task 2 (read): `licenseIdForVehicle`

Ask the contract for a vehicle's license number with `getLicenseByVehicle(pseudonym)`. Return it, or `null` when the contract answers `""`.

<details><summary>Hint</summary>

Two lines. The point of the task is the "empty string means nothing" rule from section 2.
</details>

**Check:** the two `task 2` tests pass. In the browser type a vehicle from your sample data (for example `XX-VALID`, or `SEED-1234-A` on Route B, with your own number) in the second box
and press **Find its license**; then try `NOBODY`. **Commit.**

### Task 3 (write): `revokeLicense`

Send `revokeLicense(licenseId)` as the account that is acting, and return a receipt.

1. Build the method call: `contracts.license.methods.revokeLicense(licenseId)`.
2. Send it with `sendTx(method, from, onStep)` (it is in `utils/tx.ts`: read it first; it estimates the gas, asks the account to sign, and calls `onStep` three times).
3. The contract emitted `LicenseRevoked`. Read its values from `mined.events.LicenseRevoked.returnValues`.
4. Return `makeReceipt("License Revoked", licenseId, [["vehicle", ...]], mined, timestamp)`.

**Predict:** the account that deployed the contracts is the administrator (your MetaMask account on Route A, Ganache account #0 on Route B). What happens when another account tries? (Try it after the task works: switch account in MetaMask, or pick #1 in the bar on Route B.)

<details><summary>Hint</summary>

`const ev = mined.events?.LicenseRevoked?.returnValues;` then `ev?.vehiclePseudonym` and `ev?.timestamp`. The `?.` is there because an
event could be missing; the receipt should still be built.
</details>

**Check:** the `task 3` test passes. In the browser look up the *Valid* license and press **Revoke this license**: progress steps, a receipt, and the badge turns
Revoked. MetaMask asks you to confirm (Route A), or a new `eth_sendTransaction` line appears in the chain terminal (Route B). **Commit.**

### Task 4 (events): `recentIssuedLicenses`

Read the `LicenseIssued` events and return the newest first.

1. `contracts.license.getPastEvents("LicenseIssued", { fromBlock, toBlock: "latest" })`.
2. Map each event to an `IssuedLicense`: the values are in `e.returnValues`; the block number is `e.blockNumber` (a `bigint`); the hash is `e.transactionHash`.
3. Sort by block number, highest first, and keep at most `limit`.

**Experiment (do this before you finish the task):** temporarily add `console.log(events[0].returnValues)` and look at the browser console. Find `licenseId`.
It is a long `0x...` hash, not `LIC-1234-A`. Why? (Because `licenseId` is declared `indexed` in the contract and it is a *string*: indexed values of
variable size are stored only as a hash.) Remove the `console.log` afterwards, and read the note under the table on the page: it says how the page works around this.

<details><summary>Hint: the sort</summary>

`.sort((a, b) => b.blockNumber - a.blockNumber)` puts the highest block first.
</details>

**Check:** the three `task 4` tests pass, and the right-hand list fills in. Click **Open** on a row. **Commit.**

## 5. Check your work

1. `npm test` shows 11 passes. `npm run typecheck` prints nothing.
2. Walk through AC1 to AC5 in the browser.
3. **AC6, prove that reading is free.**
   - *Route A (Sepolia):* open your account's page on https://sepolia.etherscan.io and note the newest transaction. Press **Look up** five times: MetaMask never
     opens a confirmation and Etherscan shows **no** new transaction, because each press only makes two *calls* (`getLicense`, `isLicenseValid`). Now revoke a
     license: MetaMask asks you to confirm, and a new transaction appears on Etherscan (it may take about 15 seconds).
   - *Route B (Ganache):* look at the terminal running `npm run chain`. Each press of **Look up** adds two `eth_call` lines and **no** `eth_sendTransaction`.
     (Other lines such as `eth_blockNumber` are housekeeping.) Revoking adds one `eth_sendTransaction` and a new block.

   Write down in your reflection what a call (`eth_call`) and a sent transaction (`eth_sendTransaction`) are, and who pays for each.
4. **Chain time versus your clock.** One sample license was issued with **0 days**, so it is expired as soon as the next block exists. On Route B the seed script
   waits two seconds and mines one more block so the contract agrees (look at the comment in `scripts/seed.js`); on Sepolia real blocks do that for you. Why does a
   contract only know the time of the latest *block*?

## 6. Review before you hand in

- Does each function do one job? Are the names clear?
- Did you read values by name (`raw.issued`) rather than by position (`raw[6]`)?
- Did you convert `bigint` with `Number(...)`, and seconds with `* 1000`, in exactly one place each?
- Any leftover `console.log`? Any `any` you could avoid? (A little is acceptable where web3 gives no type.)
- Does each commit message say what changed?

## 7. Stretch goals (choose one)

- **Gas cost.** Add a row to the revoke receipt showing the gas in ETH: `gasUsed * effectiveGasPrice` (both in the transaction receipt), converted with `web3.utils.fromWei`. Where do you get `web3` in `revokeLicense`?
- **Filter events.** `LicenseIssued` has `owner` as an *indexed* address, so the node can filter for you: `getPastEvents("LicenseIssued", { filter: { owner: account }, fromBlock })`. Add a "Only mine" checkbox to the page.
- **Auto-refresh.** Make the "Latest licenses issued" list refresh every 10 seconds. (Remember to clean up the timer.)
- **More tests.** Write a test where `getLicense` returns a license that is both expired and revoked, or where there are no events at all.

## 8. Hand in

1. Your branch (`git log --oneline` should show about four commits).
2. One screenshot of the desk with a status badge and a receipt on screen.
3. A reflection, three or four sentences each:
   - What is the difference between a call, a send and an event search? Give an example of each from this exercise.
   - Why can the page not read the license number from the `LicenseIssued` event, and how did the page get around it?
   - Why does `fetchLicense` read more than just `isLicenseValid`?
