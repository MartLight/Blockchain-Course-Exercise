# Deploy your own contracts with Remix (Sepolia)

You deploy the three contracts yourself, from the browser, and then tell the app where they are. You do **not** change any
Solidity. About 20 minutes. You need MetaMask on the **Sepolia** test network with a little Sepolia test ETH (a faucet gives it
for free; about 0.05 ETH is plenty). Use a throwaway wallet, never one that holds real money.

The account you deploy with becomes the **administrator** of your contracts. That is the account that can revoke licenses.

## 1. Put the five files into Remix

1. Open https://remix.ethereum.org
2. In the file explorer (left), create a folder `licenses` and upload the five files from the **`remix/`** folder of this project
   (drag them in, or use the *Upload files* button): `IVehicleRegistry.sol`, `IRevocationManager.sol`, `VehicleRegistry.sol`,
   `RevocationManager.sol`, `LicenseRegistry.sol`. Keep them together in the same folder.

These are the same contracts as in `contracts/`. Only the two OpenZeppelin `import` lines differ: they name version `5.0.2`, so Remix
downloads the same library the project uses.

## 2. Compile

1. Open the **Solidity compiler** tab. Choose compiler **0.8.20**.
2. Open *Advanced configurations*: set **EVM version** to `paris`, tick **Enable optimization**, runs `200`.
3. Select `LicenseRegistry.sol` and press **Compile**; then select `VehicleRegistry.sol` and `RevocationManager.sol` and compile each. A green
   tick appears on the compiler tab each time. (The two `I...` files are only imported by the others.)

## 3. Connect Remix to MetaMask

Open the **Deploy & run** tab. Set *Environment* to **Injected Provider - MetaMask**. MetaMask asks to connect: approve. The line
under *Environment* must say **Sepolia (11155111)**. If it does not, switch network in MetaMask first.

## 4. Deploy the three contracts, in this order

The order matters: each contract needs the address of the one before it.

| Step | In Remix | What to do |
|---|---|---|
| 1 | *Contract:* `VehicleRegistry` | Press **Deploy**, confirm in MetaMask. Under *Deployed Contracts* press the copy icon next to it: that is **address 1**. |
| 2 | *Contract:* `RevocationManager` | Next to Deploy, paste **address 1**. Deploy, confirm. Copy its address: **address 2**. |
| 3 | In the deployed **VehicleRegistry**, open `setRevocationManager` | Paste **address 2**, press **transact**, confirm. (This tells the registry who the revocation manager is. It can be done only once.) |
| 4 | *Contract:* `LicenseRegistry` | Next to Deploy, paste **address 1**, a comma, then **address 2** (`0x...,0x...`). Deploy, confirm. Copy its address: **address 3**. |

Keep the three addresses in a note. If you close Remix you can still use them again, because they live on the blockchain.

## 5. Find the block number

Open https://sepolia.etherscan.io and paste **address 3** (the LicenseRegistry). Under *Contract Creator* click the transaction link
and note the **Block** number (for example `7412345`). The app starts its search for issued licenses there, instead of at block 0.

## 6. Tell the app

Open `.env.local` in the project. Near the bottom is a section **CONTRACT ADDRESSES**. Fill in the five blank lines (no quotes, no spaces):

```
NEXT_PUBLIC_DEPLOYED_CHAIN_ID=11155111
NEXT_PUBLIC_VEHICLE_REGISTRY_ADDRESS=<address 1>
NEXT_PUBLIC_REVOCATION_MANAGER_ADDRESS=<address 2>
NEXT_PUBLIC_LICENSE_REGISTRY_ADDRESS=<address 3>
NEXT_PUBLIC_DEPLOY_BLOCK=<the block number>
```

(`NEXT_PUBLIC_WALLET_MODE=metamask` is already set; it makes the page open on the MetaMask tab.)

Stop `npm run dev` and start it again (the file is read when it starts). Open http://localhost:3000, press **Connect Wallet**, and check the
*Setup check*: all three addresses should be yours and the bar should say **administrator**. If it says *not administrator*, MetaMask is
on a different account from the one you deployed with.

Addresses in `.env.local` replace the ones in `shared/deployments.json` completely, so you never read someone else's contracts by accident.
Nothing in `.env.local` is secret (addresses are public), but do not put a private key in it.

## 7. Make sample data (so there is something to look up)

The local route has `npm run seed`; on Sepolia you make the same four licenses by hand in Remix. In the deployed contracts, expand each
and fill in the boxes (strings need quotes in Remix, numbers do not). Replace `XX` with your own initials; it keeps your screenshots clear.

| # | Contract | Function | Values |
|---|---|---|---|
| 1 | VehicleRegistry | `registerVehicle` | `"XX-VALID"` |
| 2 | VehicleRegistry | `registerVehicle` | `"XX-OLD"` |
| 3 | VehicleRegistry | `registerVehicle` | `"XX-REVOKED"` |
| 4 | VehicleRegistry | `registerVehicle` | `"XX-BADCAR"` |
| 5 | VehicleRegistry | `registerVehicle` | `"XX-REPORTER"` |
| 6 | LicenseRegistry | `issueLicense` | `"LIC-XX-A", "XX-VALID", "Class B (car)", 365` |
| 7 | LicenseRegistry | `issueLicense` | `"LIC-XX-B", "XX-OLD", "Class A (motorcycle)", 0` |
| 8 | LicenseRegistry | `issueLicense` | `"LIC-XX-C", "XX-REVOKED", "Commercial", 365` |
| 9 | LicenseRegistry | `issueLicense` | `"LIC-XX-D", "XX-BADCAR", "Class C (light truck)", 365` |
| 10 | LicenseRegistry | `revokeLicense` | `"LIC-XX-C"` |
| 11 | RevocationManager | `submitRevocationReport` | `"XX-BADCAR", "XX-REPORTER", "Practice data"` |
| 12 | RevocationManager | `processRevocation` | `1` |

Each row is one MetaMask confirmation (12 in all, a few cents of test ETH). Row 7 uses `0` days, so that license has already expired by the
time the next block is mined. Row 12 uses the report number `1` because it is the first report your contract has received.

Now look these up on the desk once Task 1 works:

| License number | You should see |
|---|---|
| `LIC-XX-A` | Valid |
| `LIC-XX-B` | Expired |
| `LIC-XX-C` | Revoked |
| `LIC-XX-D` | Vehicle revoked |

## Common problems

- **"The contracts are not deployed on Sepolia"** in the app: a `.env.local` line is missing or has a typo, or you did not restart `npm run dev`.
- **Remix says "Gas estimation failed" on step 3 or 4:** the address you pasted is wrong, or you are not on the account that deployed. For step 3 this
  also appears if `setRevocationManager` was already done.
- **The "Latest licenses issued" list is empty or an error shows:** `NEXT_PUBLIC_DEPLOY_BLOCK` is missing (the search then starts at block 0, which the
  public Sepolia server may refuse) or is later than your first license.
- **Looking up a license number shows "No license with that number":** the number is typed differently (capitals and dashes must match exactly) or you
  are connected to a different account/chain than the one that holds the contracts.
- **MetaMask shows many pending requests:** deal with them one at a time. Do not press Deploy twice.
