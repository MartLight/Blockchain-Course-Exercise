#!/usr/bin/env node
// Puts a few vehicles and licenses on the local chain so the License desk has something to show.
// Run after `npm run chain` and `npm run deploy:local`:   npm run seed
//
// It creates four licenses, one in each state the desk can show:
//   valid, expired, revoked by the administrator, and "vehicle revoked".
const Web3 = require("web3").default || require("web3").Web3 || require("web3");
const abi = require("../utils/abi.json");
const publicDeployments = require("../shared/deployments.json");
const localDeployments = require("../shared/deployments.local.json");

const URL = process.env.NEXT_PUBLIC_GANACHE_URL || "http://127.0.0.1:7545";

async function main() {
  const web3 = new Web3(URL);
  const chainId = String(await web3.eth.getChainId());
  // Same lookup as utils/chain.ts: public chains by chain id, Ganache (shared/deployments.local.json) by its stored chainId.
  const d = publicDeployments[chainId] || Object.values(localDeployments).find((e) => String(e.chainId) === chainId);
  if (!d || !d.VehicleRegistry || !d.RevocationManager || !d.LicenseRegistry) {
    throw new Error(`The contracts are not deployed on chain ${chainId}. Run "npm run deploy:local" first.`);
  }
  const [admin] = await web3.eth.getAccounts();
  const registry = new web3.eth.Contract(abi.VehicleRegistry, d.VehicleRegistry.address);
  const revocation = new web3.eth.Contract(abi.RevocationManager, d.RevocationManager.address);
  const license = new web3.eth.Contract(abi.LicenseRegistry, d.LicenseRegistry.address);
  const send = (m) => m.send({ from: admin, gas: "500000" });

  const n = Math.floor(1000 + Math.random() * 9000);
  const V = { valid: `SEED-${n}-A`, expired: `SEED-${n}-B`, revoked: `SEED-${n}-C`, vehicleRevoked: `SEED-${n}-D`, reporter: `SEED-${n}-R` };
  const L = { valid: `LIC-${n}-A`, expired: `LIC-${n}-B`, revoked: `LIC-${n}-C`, vehicleRevoked: `LIC-${n}-D` };

  for (const v of [V.vehicleRevoked, V.revoked, V.expired, V.valid, V.reporter]) await send(registry.methods.registerVehicle(v));
  await send(license.methods.issueLicense(L.valid, V.valid, "Class B (car)", 365));
  await send(license.methods.issueLicense(L.expired, V.expired, "Class A (motorcycle)", 0));   // 0 days: expires at once
  await send(license.methods.issueLicense(L.revoked, V.revoked, "Commercial", 365));
  await send(license.methods.issueLicense(L.vehicleRevoked, V.vehicleRevoked, "Class C (light truck)", 365));
  await send(license.methods.revokeLicense(L.revoked));                                         // administrator revokes a license
  await send(revocation.methods.submitRevocationReport(V.vehicleRevoked, V.reporter, "Seed data"));
  const id = await revocation.methods.reportCount().call();
  await send(revocation.methods.processRevocation(id));                                         // ...and a whole vehicle

  // A contract judges "expired" by the timestamp of the LATEST BLOCK. On a quiet local chain that block is old, so a
  // license that expired a moment ago would still look valid. Wait two real seconds, then mine one block: the new block's
  // timestamp is later than the 0-day license's expiry, so the contract and the page (which uses your clock) agree.
  // (The chain clock is never moved, so running the seed again later is safe.)
  const rpc = (method, params) =>
    fetch(URL, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
  await new Promise((resolve) => setTimeout(resolve, 2000));
  await rpc("evm_mine", []);

  console.log("Seeded. Try these license numbers on the License desk:\n");
  console.log(`  ${L.valid}            expected: Valid`);
  console.log(`  ${L.expired}            expected: Expired`);
  console.log(`  ${L.revoked}            expected: Revoked`);
  console.log(`  ${L.vehicleRevoked}            expected: Vehicle revoked`);
}
main().catch((e) => { console.error("Seed failed:", e.message); process.exit(1); });
