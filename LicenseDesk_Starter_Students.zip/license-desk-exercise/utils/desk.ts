import type { Contracts } from "./chain";
import { Receipt, makeReceipt } from "./receipts";
import { Step, sendTx } from "./tx";

// YOUR JOB: write the four functions below (Tasks 1 to 4 of EXERCISE.md). Each one has its specification in the
// comment above it, and `npm test` checks it. Imports you will need are already here.
//
// The "license desk": everything the page needs from the chain, in four small functions.
// Each function takes the `contracts` object (built in utils/chain.ts) and talks to ONE contract method.
//
//   READ  = .call()          asks a question; free; no wallet pop-up; returns the answer
//   WRITE = .send(...)       changes the chain; costs gas; the account must sign; returns a receipt
//   EVENTS = getPastEvents   reads the log the contracts wrote while they ran

export type LicenseStatus = "valid" | "expired" | "revoked" | "vehicle-revoked";

export interface LicenseInfo {
  licenseId: string;
  vehicle: string;
  owner: string;
  type: string;
  issuedAt: Date;
  expiresAt: Date;
  isActive: boolean;          // false once an administrator has revoked this license
  valid: boolean;             // the contract's own verdict (isLicenseValid)
  status: LicenseStatus;      // WHY it is or is not valid, worked out from the fields
}

export interface IssuedLicense {
  vehicle: string;
  type: string;
  owner: string;
  issuedAt: Date;
  expiresAt: Date;
  blockNumber: number;
  txHash: string;
}

// ---------------------------------------------------------------------------------------------------
// TASK 1 (read): look up one license.
//
// getLicense(licenseId) returns, by name: vehiclePseudonym, owner, licenseType, issueTime, expiryTime,
// isActive, issued.  Times are in SECONDS (as bigint). isLicenseValid(licenseId) returns true/false.
//
//  * If `issued` is false, no such license exists: return null.
//  * Otherwise return a LicenseInfo. Work out `status` in THIS order:
//        valid           the contract says it is valid
//        revoked         it is not active (an administrator revoked this license)
//        expired         it is active but the expiry time has passed (compare with `now`, in milliseconds)
//        vehicle-revoked it is active and not expired, yet invalid: the VEHICLE was revoked
// ---------------------------------------------------------------------------------------------------
export async function fetchLicense(contracts: Contracts, licenseId: string, now: number = Date.now()): Promise<LicenseInfo | null> {
  throw new Error("TODO Task 1: write fetchLicense in utils/desk.ts");
}

// ---------------------------------------------------------------------------------------------------
// TASK 2 (read): which license does a vehicle have?
//
// getLicenseByVehicle(pseudonym) returns the id of the vehicle's latest license, or an EMPTY STRING if it has none.
// Return the id, or null when it is empty.
// ---------------------------------------------------------------------------------------------------
export async function licenseIdForVehicle(contracts: Contracts, pseudonym: string): Promise<string | null> {
  throw new Error("TODO Task 2: write licenseIdForVehicle in utils/desk.ts");
}

// ---------------------------------------------------------------------------------------------------
// TASK 3 (write): revoke a license. Only the administrator may do this.
//
// The method is revokeLicense(licenseId). Use sendTx (utils/tx.ts) to send it: it estimates the gas, asks the
// account to sign, and reports progress through `onStep`. The contract then emits LicenseRevoked, whose values are
// in  mined.events.LicenseRevoked.returnValues  (vehiclePseudonym, timestamp).
// Return a receipt: makeReceipt("License Revoked", licenseId, [["vehicle", ...]], mined, timestamp)
// ---------------------------------------------------------------------------------------------------
export async function revokeLicense(
  contracts: Contracts,
  from: string,
  licenseId: string,
  onStep: (step: Step, txHash?: string) => void
): Promise<Receipt> {
  throw new Error("TODO Task 3: write revokeLicense in utils/desk.ts");
}

// ---------------------------------------------------------------------------------------------------
// TASK 4 (events): the most recent licenses issued.
//
// Every issueLicense call emits LicenseIssued. Ask for them with
//     contracts.license.getPastEvents("LicenseIssued", { fromBlock, toBlock: "latest" })
// Each event has: returnValues (vehiclePseudonym, owner, licenseType, issueTime, expiryTime), blockNumber (bigint),
// transactionHash.   Return the newest first (highest blockNumber first), at most `limit` of them.
//
// WATCH OUT: licenseId is an INDEXED string, so the event stores only its hash. You cannot get the license number
// back from the event. (That is why the page uses licenseIdForVehicle when you click a row.)
// ---------------------------------------------------------------------------------------------------
export async function recentIssuedLicenses(contracts: Contracts, fromBlock: number, limit: number = 10): Promise<IssuedLicense[]> {
  throw new Error("TODO Task 4: write recentIssuedLicenses in utils/desk.ts");
}
