import { useCallback, useEffect, useState } from "react";
import NotReady from "../components/NotReady";
import ReceiptCard from "../components/ReceiptCard";
import TxStatus from "../components/TxStatus";
import { useReady } from "../context/WalletContext";
import { useTransaction } from "../hooks/useTransaction";
import { startBlock } from "../utils/chain";
import { IssuedLicense, LicenseInfo, LicenseStatus, fetchLicense, licenseIdForVehicle, recentIssuedLicenses, revokeLicense } from "../utils/desk";
import { friendlyError } from "../utils/errors";
import { Receipt } from "../utils/receipts";

// THE LICENSE DESK. The screen is finished and given. It calls the four functions in utils/desk.ts,
// which are the exercise: until you write them, each section shows a "TODO" message.

const STATUS: Record<LicenseStatus, { label: string; cls: string; note: string }> = {
  valid: { label: "Valid", cls: "ok", note: "Active, not expired, and the vehicle is in good standing." },
  expired: { label: "Expired", cls: "warn", note: "The expiry time has passed." },
  revoked: { label: "Revoked", cls: "bad", note: "An administrator revoked this license." },
  "vehicle-revoked": { label: "Vehicle revoked", cls: "bad", note: "The license is fine, but its vehicle has been revoked." },
};

function expiryText(expiresAt: Date, now = Date.now()): string {
  const days = Math.round((expiresAt.getTime() - now) / 86_400_000);
  if (days > 1) return `expires in ${days} days`;
  if (days === 1) return "expires in 1 day";
  if (days === 0) return "expires today";
  return `expired ${-days} day${days === -1 ? "" : "s"} ago`;
}

export default function DeskPage() {
  const ready = useReady();
  const [licenseId, setLicenseId] = useState("");
  const [vehicle, setVehicle] = useState("");
  const [info, setInfo] = useState<LicenseInfo | null | undefined>(undefined); // undefined: nothing looked up yet; null: not found
  const [lookupError, setLookupError] = useState("");
  const [looking, setLooking] = useState(false);
  const [recent, setRecent] = useState<IssuedLicense[] | null>(null);
  const [recentError, setRecentError] = useState("");
  const revoke = useTransaction<Receipt>();

  const contracts = ready?.contracts;
  const chainId = ready?.wallet.chainId;

  const lookup = useCallback(async (id: string) => {
    if (!contracts || !id.trim()) return;
    setLooking(true);
    setLookupError("");
    try {
      setInfo(await fetchLicense(contracts, id.trim()));
    } catch (err) {
      setInfo(undefined);
      setLookupError(friendlyError(err));
    } finally {
      setLooking(false);
    }
  }, [contracts]);

  async function findByVehicle(name: string) {
    if (!contracts || !name.trim()) return;
    setLookupError("");
    try {
      const id = await licenseIdForVehicle(contracts, name.trim());
      if (id === null) {
        setInfo(undefined);
        setLookupError(`"${name.trim()}" has no license.`);
        return;
      }
      setLicenseId(id);
      await lookup(id);
    } catch (err) {
      setLookupError(friendlyError(err));
    }
  }

  const loadRecent = useCallback(async () => {
    if (!contracts || !chainId) return;
    setRecentError("");
    try {
      setRecent(await recentIssuedLicenses(contracts, startBlock(chainId), 10));
    } catch (err) {
      setRecent(null);
      setRecentError(friendlyError(err));
    }
  }, [contracts, chainId]);

  useEffect(() => { void loadRecent(); }, [loadRecent]);

  if (!ready) return <NotReady />;
  const { wallet, isAdmin } = ready;

  async function doRevoke() {
    if (!info || !contracts) return;
    const receipt = await revoke.run((onStep) => revokeLicense(contracts, wallet.account, info.licenseId, onStep));
    if (receipt) await lookup(info.licenseId);
  }

  return (
    <>
      <div className="hero">
        <h1>License desk</h1>
        <div className="muted">Look up a license, see why it is or is not valid, revoke it as administrator, and list the latest issues. Every number comes from the chain.</div>
      </div>

      <div className="grid2">
        <div className="stack">
          <div className="card stack">
            <h2>Look up a license</h2>
            <div className="row">
              <input className="input" placeholder="license number, e.g. LIC-1234" value={licenseId}
                onChange={(e) => setLicenseId(e.target.value)} onKeyDown={(e) => e.key === "Enter" && lookup(licenseId)} />
              <button className="btn" onClick={() => lookup(licenseId)} disabled={looking}>{looking ? "Reading..." : "Look up"}</button>
            </div>
            <div className="row">
              <input className="input" placeholder="or a vehicle pseudonym" value={vehicle}
                onChange={(e) => setVehicle(e.target.value)} onKeyDown={(e) => e.key === "Enter" && findByVehicle(vehicle)} />
              <button className="btn secondary" onClick={() => findByVehicle(vehicle)}>Find its license</button>
            </div>
            {lookupError && <div className="msg err">{lookupError}</div>}
            {info === null && <div className="msg warn">No license with that number was ever issued.</div>}
          </div>

          {info && (
            <div className="card stack">
              <div className="row between">
                <h2 style={{ margin: 0 }}>{info.licenseId}</h2>
                <span className={`badge ${STATUS[info.status].cls}`}>{STATUS[info.status].label}</span>
              </div>
              <div className="muted">{STATUS[info.status].note}</div>
              <table className="tbl">
                <tbody>
                  <tr><td>Vehicle</td><td><code>{info.vehicle}</code></td></tr>
                  <tr><td>Type</td><td>{info.type}</td></tr>
                  <tr><td>Holder</td><td><code>{info.owner}</code></td></tr>
                  <tr><td>Issued</td><td>{info.issuedAt.toLocaleString()}</td></tr>
                  <tr><td>Expires</td><td>{info.expiresAt.toLocaleString()} <span className="muted">({expiryText(info.expiresAt)})</span></td></tr>
                </tbody>
              </table>

              {info.status === "valid" && (
                <div className="stack">
                  {isAdmin === false && <div className="msg warn">Only the administrator can revoke. Pick account #0 in the bar above.</div>}
                  <div><button className="btn danger" onClick={doRevoke} disabled={revoke.busy || isAdmin === false}>{revoke.busy ? "Working..." : "Revoke this license"}</button></div>
                </div>
              )}
              <TxStatus tx={revoke.tx} successText="License revoked on the chain." />
              {revoke.result && <ReceiptCard receipt={revoke.result} />}
            </div>
          )}
        </div>

        <div className="card stack">
          <div className="row between">
            <h2 style={{ margin: 0 }}>Latest licenses issued</h2>
            <button className="btn small secondary" onClick={loadRecent}>Refresh</button>
          </div>
          {recentError && <div className="msg err">{recentError}</div>}
          {recent && recent.length === 0 && <div className="muted">None yet. Issue one in Demo 3, or run <code>npm run seed</code>.</div>}
          {recent && recent.length > 0 && (
            <table className="tbl">
              <thead><tr><th>Vehicle</th><th>Type</th><th>Block</th><th /></tr></thead>
              <tbody>
                {recent.map((r) => (
                  <tr key={r.txHash}>
                    <td><b>{r.vehicle}</b></td>
                    <td>{r.type}</td>
                    <td>#{r.blockNumber}</td>
                    <td><button className="btn small secondary" onClick={() => { setVehicle(r.vehicle); void findByVehicle(r.vehicle); }}>Open</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <div className="muted">
            Read from the <code>LicenseIssued</code> events, not from a database. The event holds only a <i>hash</i> of the license
            number, so "Open" asks the contract for the vehicle's license.
          </div>
        </div>
      </div>
    </>
  );
}
