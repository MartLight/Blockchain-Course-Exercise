import test from "node:test";
import assert from "node:assert/strict";
import { fetchLicense, licenseIdForVehicle, recentIssuedLicenses, revokeLicense } from "../utils/desk";
import { makeFakes } from "./fakes";

// These tests are the SPECIFICATION of the four tasks. They use fake contracts, so no blockchain is needed.
// Run them with:  npm test

const DAY = 86_400; // seconds
const NOW_S = 1_800_000_000;
const NOW_MS = NOW_S * 1000;
const record = (over: Record<string, unknown> = {}) => ({
  vehiclePseudonym: "KA-2041-GH", owner: "0xAbC", licenseType: "Class B (car)",
  issueTime: BigInt(NOW_S - 10 * DAY), expiryTime: BigInt(NOW_S + 355 * DAY), isActive: true, issued: true, ...over,
});

// ---- Task 1 ----
test("task 1: a license that was never issued gives null", async () => {
  const { contracts } = makeFakes({ getLicense: () => record({ issued: false }), isLicenseValid: () => false });
  assert.equal(await fetchLicense(contracts, "LIC-0", NOW_MS), null);
});

test("task 1: a valid license: fields are mapped and times become Dates", async () => {
  const { contracts, calls } = makeFakes({ getLicense: () => record(), isLicenseValid: () => true });
  const info = await fetchLicense(contracts, "LIC-1", NOW_MS);
  assert.ok(info);
  assert.equal(info.status, "valid");
  assert.equal(info.valid, true);
  assert.equal(info.licenseId, "LIC-1");
  assert.equal(info.vehicle, "KA-2041-GH");
  assert.equal(info.type, "Class B (car)");
  assert.equal(info.owner, "0xAbC");
  assert.equal(info.expiresAt.getTime(), (NOW_S + 355 * DAY) * 1000, "times are seconds on the chain, milliseconds in a Date");
  assert.deepEqual(calls.find((c) => c.name === "getLicense")?.args, ["LIC-1"]);
});

test("task 1: expired", async () => {
  const { contracts } = makeFakes({ getLicense: () => record({ expiryTime: BigInt(NOW_S - DAY) }), isLicenseValid: () => false });
  assert.equal((await fetchLicense(contracts, "LIC-2", NOW_MS))?.status, "expired");
});

test("task 1: revoked by an administrator (even if it has also expired)", async () => {
  const { contracts } = makeFakes({ getLicense: () => record({ isActive: false }), isLicenseValid: () => false });
  assert.equal((await fetchLicense(contracts, "LIC-3", NOW_MS))?.status, "revoked");
  const both = makeFakes({ getLicense: () => record({ isActive: false, expiryTime: BigInt(NOW_S - DAY) }), isLicenseValid: () => false });
  assert.equal((await fetchLicense(both.contracts, "LIC-3", NOW_MS))?.status, "revoked");
});

test("task 1: active and not expired, but invalid: the vehicle was revoked", async () => {
  const { contracts } = makeFakes({ getLicense: () => record(), isLicenseValid: () => false });
  assert.equal((await fetchLicense(contracts, "LIC-4", NOW_MS))?.status, "vehicle-revoked");
});

// ---- Task 2 ----
test("task 2: an empty string means 'no license': null", async () => {
  const { contracts } = makeFakes({ getLicenseByVehicle: () => "" });
  assert.equal(await licenseIdForVehicle(contracts, "KA-1"), null);
});

test("task 2: returns the id and asks about the right vehicle", async () => {
  const { contracts, calls } = makeFakes({ getLicenseByVehicle: () => "LIC-77" });
  assert.equal(await licenseIdForVehicle(contracts, "KA-2041-GH"), "LIC-77");
  assert.deepEqual(calls.find((c) => c.name === "getLicenseByVehicle")?.args, ["KA-2041-GH"]);
});

// ---- Task 3 ----
test("task 3: revoking sends revokeLicense(id) and builds a receipt from the event", async () => {
  const receipt = {
    transactionHash: "0xabc123", blockNumber: 12n, gasUsed: 45000n,
    events: { LicenseRevoked: { returnValues: { vehiclePseudonym: "KA-2041-GH", timestamp: BigInt(NOW_S) } } },
  };
  const { contracts, calls } = makeFakes({ receipt });
  const steps: string[] = [];
  const r = await revokeLicense(contracts, "0xAdmin", "LIC-9", (s) => steps.push(s));

  assert.deepEqual(calls.find((c) => c.name === "revokeLicense")?.args, ["LIC-9"]);
  assert.deepEqual(steps, ["wallet", "sent", "mined"], "progress is reported through onStep (sendTx does this)");
  assert.equal(r.title, "License Revoked");
  assert.equal(r.subject, "LIC-9");
  assert.deepEqual(r.rows, [["vehicle", "KA-2041-GH"]]);
  assert.equal(r.txHash, "0xabc123");
  assert.equal(r.blockNumber, 12);
  assert.equal(r.gasUsed, 45000);
});

// ---- Task 4 ----
const issuedEvent = (block: number, vehicle: string) => ({
  blockNumber: BigInt(block), transactionHash: "0xtx" + block,
  returnValues: { vehiclePseudonym: vehicle, owner: "0xOwner", licenseType: "Class B (car)", issueTime: BigInt(NOW_S), expiryTime: BigInt(NOW_S + DAY) },
});

test("task 4: asks for LicenseIssued events from the given block", async () => {
  const { contracts, calls } = makeFakes({ pastEvents: [] });
  await recentIssuedLicenses(contracts, 123);
  const call = calls.find((c) => c.name === "getPastEvents");
  assert.equal(call?.args[0], "LicenseIssued");
  assert.equal((call?.args[1] as any).fromBlock, 123);
});

test("task 4: newest first, limited, and mapped to plain values", async () => {
  const { contracts } = makeFakes({ pastEvents: [issuedEvent(5, "A"), issuedEvent(9, "C"), issuedEvent(7, "B"), issuedEvent(3, "Z")] });
  const list = await recentIssuedLicenses(contracts, 0, 3);
  assert.deepEqual(list.map((l) => l.vehicle), ["C", "B", "A"]);
  assert.equal(list[0].blockNumber, 9);
  assert.equal(list[0].txHash, "0xtx9");
  assert.equal(list[0].issuedAt.getTime(), NOW_MS);
  assert.equal(list[0].expiresAt.getTime(), (NOW_S + DAY) * 1000);
  assert.equal(list[0].type, "Class B (car)");
});

test("task 4: the default limit is 10", async () => {
  const many = Array.from({ length: 15 }, (_, i) => issuedEvent(i + 1, "V" + i));
  const { contracts } = makeFakes({ pastEvents: many });
  assert.equal((await recentIssuedLicenses(contracts, 0)).length, 10);
});
