// Test doubles: tiny fake contracts, so the four functions can be tested WITHOUT a blockchain.
// (A "fake" stands in for the real thing and records how it was used. This is how you test code that talks to the network.)
import type { Contracts } from "../utils/chain";

export interface Calls { name: string; args: unknown[] }

// A fake PromiEvent: awaiting it gives the receipt; .on("transactionHash", cb) is called like the real one.
function fakeSend(receipt: any) {
  const p: any = Promise.resolve(receipt);
  p.on = (event: string, cb: (v: string) => void) => {
    if (event === "transactionHash") cb(receipt.transactionHash);
    return p;
  };
  return p;
}

export function makeFakes(opts: {
  getLicense?: (id: string) => any;
  isLicenseValid?: (id: string) => boolean;
  getLicenseByVehicle?: (v: string) => string;
  pastEvents?: any[];
  receipt?: any;
}) {
  const calls: Calls[] = [];
  const record = (name: string, args: unknown[]) => calls.push({ name, args });

  const license = {
    methods: {
      getLicense: (id: string) => { record("getLicense", [id]); return { call: async () => opts.getLicense!(id) }; },
      isLicenseValid: (id: string) => { record("isLicenseValid", [id]); return { call: async () => opts.isLicenseValid!(id) }; },
      getLicenseByVehicle: (v: string) => { record("getLicenseByVehicle", [v]); return { call: async () => opts.getLicenseByVehicle!(v) }; },
      revokeLicense: (id: string) => {
        record("revokeLicense", [id]);
        return { estimateGas: async () => 100000n, send: () => fakeSend(opts.receipt) };
      },
    },
    getPastEvents: async (name: string, options: unknown) => { record("getPastEvents", [name, options]); return opts.pastEvents ?? []; },
  };
  return { contracts: { license } as unknown as Contracts, calls };
}
